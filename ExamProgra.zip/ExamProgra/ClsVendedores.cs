﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    public class ClsVendedores
    {
        public Dictionary<int, string> vendedores;

        public static ClsVendedores Vendedores = new ClsVendedores();

        public ClsVendedores()
        {
            vendedores.Add(1, "Vendedor1");
            vendedores.Add(2, "Vendedor2");
        }

        public void ListadoVendedores()
        {
            foreach (var vendedor in vendedores)
            {
                Console.WriteLine($"Código: {vendedor.Key}, Nombre del vendedor: {vendedor.Value}");
            }
           
        }

        public string NombreVendedor(int codigo)
        {
            if (vendedores.ContainsKey(codigo))

                return vendedores[codigo];
            else
                return "Vendedor no encontrado";


        }

        
    }
}
