﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    public class Vendedor1 : ClsVendedores,IVendedor1
    {
        public Vendedor1(string Nombre)
        {
            if (Nombre is null)
            {
                throw new ArgumentNullException(nameof(Nombre));
            }

            vendedores.Add(1, Nombre);
        }

        public void VentasContado()
        {
            Console.WriteLine("Ventas al contado");
        }
    }
}
