﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    public class ClsArticulos
    {
        protected int[] Codigo { get; set; }
        protected string[] Nombre { get; set; }
        protected double[] Precio { get; set; }
        public int NumArticulos = 0;

        protected Dictionary<int, (string nombre, double precio)> articulos = new Dictionary<int, (string, double)>();

        public ClsArticulos()
        {
            Codigo = new int[5];
            Nombre = new string[5];
            Precio = new double[5];


        }

        public ClsArticulos(int[] codigo, string[] nombre, double[] precio)
        {
            Codigo = codigo;
            Nombre = nombre;
            Precio = precio;
        }

        public ClsArticulos(int codigo, string nombre, double precio)
        {
        }

        public static void AgregarArticulos()
        {
            Boolean fin = true;
            do
            {
                if (NumArticulos >= 5)
                {
                    Console.WriteLine("No se pueden agregar más de 5 artículos");

                }
                else
                {
                    Console.Write("Ingrese el código del nuevo artículo: ");
                    int codigo = int.Parse(Console.ReadLine());

                    Console.Write("Ingrese el nombre del artículo: ");
                    string nombre = Console.ReadLine();

                    Console.Write("Ingrese el precio del artículo: ");
                    double precio = double.Parse(Console.ReadLine());

                    Console.WriteLine("El artículo fue agregado correctamente");
                    Console.WriteLine("Desea ingresar otro producto");
                    string n = Console.ReadLine();



                    articulos.Add(new ClsArticulos( codigo, nombre, precio));
                    if (!n.Equals("n")) fin = false;
                    NumArticulos++;
                }
            } while (fin);
            
           
            
        }

        public void ConsultarArticulo(int codigo)
        {
            for (int i = 0; i < NumArticulos; i++)
            {
                if (Codigo[i] == codigo)
                {
                    Console.WriteLine($"Código: {Codigo[i]}, Nombre: {Nombre[i]}, Precio: {Precio[i]}");
                    
                }
                else
                {
                    Console.WriteLine("El artículo no fue encontrado.");
                }
            }
            
        }
        public static void Consultar()
        {
            Console.Write("Ingrese el código del artículo: ");
            int codigo = int.Parse(Console.ReadLine());

            articulos.ConsultarArticulo(codigo);
        }
        public static void BorrarArticulo()
        {
            Console.Write("Ingrese el código del artículo: ");
            int codigo = int.Parse(Console.ReadLine());

            if (articulos.Remove(codigo))
            {
                Console.WriteLine($"El artículo con código {codigo} fue borrado.");
            }
            else
            {
                Console.WriteLine($"El artículo con código {codigo} no existe.");
            }
        }
    }
}
