﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    internal class ClsCategoria3: ClsCategorias
    {
        public static void Promocion()
        {
            Console.WriteLine("Todo por mitad de precio");
        }

        public int GetCodigo()
        {
            return 3; 
        }
    }
}
