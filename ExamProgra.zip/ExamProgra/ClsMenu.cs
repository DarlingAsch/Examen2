﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    static class ClsMenu 
    {
       public static ClsArticulos articulos = new ClsArticulos();

        static ClsVendedores Vendedores = new ClsVendedores();

        static ClsCategorias categorias = new ClsCategorias();
        public static void menu()
        {


            Console.WriteLine("Menú Principal");
            Console.WriteLine("a-Artículos");
            Console.WriteLine("b-Facturación");
            Console.WriteLine("c-Reporte");
            Console.WriteLine("d-Salir");
            Console.Write("Digite una opción: ");
            char op = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (op)
            {
                case 'a':
                    Submenu();
                    break;
                case 'b':
                    Facturacion();
                    break;
                case 'c':
                    Reporte();
                    break;
                case 'd':
                    Console.WriteLine("Saliendo del programa...");

                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }

        }
        static void Submenu()
        {

            Console.WriteLine("Submenú de Artículos");
            Console.WriteLine("a-Agregar");
            Console.WriteLine("b-Borrar");
            Console.WriteLine("c-Consultar");
            Console.Write("Seleccione una opción: ");
            char op = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (op)
            {
                case 'a':
                    ClsArticulos.AgregarArticulos();
                    break;
                case 'b':
                    ClsArticulos.BorrarArticulo();
                    break;
                case 'c':
                    ClsArticulos.Consultar();
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }

        }
        

        
        
        static void Facturacion()
        {
            
            Console.WriteLine("Ingrese el código del artículo");
            int codigo = int.Parse(Console.ReadLine());

            string nombre = Console.ReadLine();
            double precio = double.Parse(Console.ReadLine());

            if (nombre != null)
            {

                Console.WriteLine($"Artículo: {nombre}");
                Console.WriteLine($"Precio: {precio}");


                Console.Write("Ingrese la categoría del artículo: ");
                string categoria = Console.ReadLine();
                if (!categorias.Equals(categoria))
                {
                    Console.WriteLine($"La categoría del artículo es: {categoria}");
                   
                }
            }
        }

        
        static void Reporte(int NumArticulos, int codigo,string nombre, double precio)
        {
           
              
                Console.WriteLine("Artículos ingresados:");
            for (int i = 0; i < NumArticulos; i++)
            {
                Console.WriteLine($"Nombre del artículo: {nombre}");
                Console.WriteLine($"Código del artículo: {codigo}");
                Console.WriteLine($"Precio del artículo: {precio}");
            }

        }

    }
}
