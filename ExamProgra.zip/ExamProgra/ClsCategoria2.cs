﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    internal class ClsCategoria2: ClsCategorias
    {
        public static void Promocion()
        {
            Console.WriteLine("Promoción 2x1");
        }

        public int GetCodigo()
        {
            return 2; 
        }
    }
}
