﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    internal class Program
    {
        
        public static void Main(string[] args)
        {
            
            List<ClsCategorias> categorias = new List<ClsCategorias>();

            categorias.Add(new ClsCategoria1());
            categorias.Add(new ClsCategoria2());
            categorias.Add(new ClsCategoria3());

            ClsMenu.menu();
        }


    }
}
