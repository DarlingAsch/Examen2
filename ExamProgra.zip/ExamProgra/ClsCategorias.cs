﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    public class ClsCategorias
    {
        

             public void Promocion()
        {
            Console.WriteLine("---Descuentos y promociones---");
        }

        public void ListadoCategorias(List<ClsCategorias> categorias)
        {
            foreach (ClsCategorias categoria in categorias)
            {
                categoria.Promocion();
            }
        }
            public static bool categoriaExiste(int codigo, List<ClsCategorias> categorias)
            {
                foreach (ClsCategorias categoria in categorias)
                {
                    if (categoria.GetCodigo() == codigo)
                        return true;
                }
                return false;
            }

        public int GetCodigo()
        {
            return 0;
        }
    }
}
