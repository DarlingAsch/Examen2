﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    internal interface IVendedor2
    {
        string VentasCredito();
    }
}
