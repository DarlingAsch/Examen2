﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProgra
{
    internal class Vendedor2 : ClsVendedores, IVendedor2
    {
        public Vendedor2(string nombre)
        {
            vendedores.Add(2, nombre);
        }

        public string VentasCredito()
        {
            return "Ventas a crédito";
        }
    
    }
}
